
package week12;


public class Car extends Vehicle {
    public Car() {
        
    }
    public void special() {
        System.out.println("This is to run car object");         
    }
    public int getRandom(int num) {
        return num*2;
    }
}
