
package week12;

public interface Number {
    
    public String toString();
    public int getSpecial();
    
}
