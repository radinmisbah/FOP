package week12;

public abstract class Vehicle {
    // instance variables
    private int number;
    // methods
    public void abc() {
        System.out.println("Testing");
    }
            
    // abstract methods
    public abstract void special();
    public abstract int getRandom(int num); 
    
    
}
