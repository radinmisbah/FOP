
package week12;


public class Boat extends Vehicle {
    public Boat() {
        
    }
    public void special() {
        System.out.println("This is to run boat object");         
    }
    public int getRandom(int num) {
        return num*5;
    }
}
