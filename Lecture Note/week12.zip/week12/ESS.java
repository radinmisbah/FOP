
package week12;


public abstract class ESS {
    public abstract double getSalary();
}

 