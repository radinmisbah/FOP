    
package week10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Week10 {

    public static void main(String[] args) {
        /*
        // create objects from the class
        // object without argument, 
        //a - ABC, Kepong, 20 
        //b - CDE, PJ, 10
        Restaurant a = new Restaurant(); 
        Restaurant b = new Restaurant(); 
        // a.name = "ABC"; cannot, must use mutator
        a.setName("ABC");
        a.setAddress("Kepong");
        a.setNumOfEmployee(20);
        b.setName("CDE");
        b.setAddress("PJ");
        b.setNumOfEmployee(10);
        System.out.println(a.toString());
        System.out.println(b.toString());
        
        if (a.getNumOfEmployee() > b.getNumOfEmployee()) {
            System.out.println(a.getName() + " is bigger");
        }
        else
            System.out.println(b.getName() + " is bigger");
        
        //System.out.println(a.name); cannot, must use accessor
        */
        /*
        // object with argument
        //c - XYZ, KL, 50
        Restaurant c = new Restaurant("XYZ","KL",50); 
        System.out.println(c.toString());
        // I want to make a copy of C object
        // Restaurant d = c; cannot because object is reference data type
        Restaurant d = new Restaurant(c); 
        //Restaurant e = null;
        //Restaurant d = new Restaurant(e); 
        
        // object is reference data type
        special(d);
        System.out.println(c.toString());
        
        // array of object
        int size = 5;
        Restaurant[] rest = new Restaurant[size];  
        // use foor loop
        rest[0] = new Restaurant("OPQ","Serdang",30); 
        rest[1] = new Restaurant("LMN","Kajang",22); 
        System.out.println(rest[0].toString());
        System.out.println(rest[1].toString());
        */
        /*
        // write a program to create the Book class
        // the attribute values of the class is stored 
        // in a text file named book.txt
        try {
            String fileName = "book.txt";
            Scanner in = new Scanner(new FileInputStream(fileName));
            int cnt=0;
            while(in.hasNextLine()) {
                in.nextLine();
                cnt++;
            }
            in.close();
            in = new Scanner(new FileInputStream(fileName));
            Book[] book = new Book[cnt];
            for(int i=0; i<book.length; i++) {
                String[] raw = in.nextLine().split(",");
                int y = Integer.parseInt(raw[1]);
                double p = Double.parseDouble(raw[3]);
                book[i] = new Book(raw[0], raw[2], y, p);
            }
            in.close();
            System.out.println("The book details are : ");
            for(int i=0; i<book.length; i++) {
                System.out.println(book[i].toString());
            }
         } catch (FileNotFoundException e) {
            System.out.println("File was not found"); 
         }
        */
         // static variable
        Book b1 = new Book();
        Book b2 = new Book();
        b1.setColor("Blue");
        b2.setColor("Green");
        System.out.println("B1 - " + b1.getColor());
        System.out.println("B2 - " + b2.getColor());
        
        // to call static method
        System.out.println("Color - " + Book.GETCOLOR());
        
    }
    
    public static void special(Restaurant a) {
        a.setAddress("Johor");
    }
    
}
