package week10;


// create a new class (restaurant, school, ...)
   // instance variable
   // constructor
   // methods

public class Restaurant {
    // instance variable
    private String name, address;
    private int numOfEmployee;

    public Restaurant() {
        name = "";
        address = "";
        numOfEmployee=0;
    }

    public Restaurant(String name, String address, int numOfEmployee) {        
        this.name = name;
        this.address = address;
        this.numOfEmployee = numOfEmployee;
    }

    //copy constructor
    public Restaurant(Restaurant a) {
        if (a!=null) {
            name = a.getName();
            address = a.getAddress();
            numOfEmployee=a.getNumOfEmployee();
        }
    }
        
    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setNumOfEmployee(int numOfEmployee) {
        this.numOfEmployee = numOfEmployee;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getNumOfEmployee() {
        return numOfEmployee;
    }

    public String toString() {
        String str = "Restaurant : " + name + "\nAddress : " + address + "\n";
        str = str + "Number of Employee : " + numOfEmployee;
        return str; 
    }
       
    
}
