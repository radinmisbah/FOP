package week10;

public class Book {
    private String bookTitle, publisher; 
    private int year;
    private double price; 
    
    private static String color;

    public Book(){
            
    }
    
    public Book(String bookTitle, String publisher, int year, double price) {
        this.bookTitle = bookTitle;
        this.publisher = publisher;
        this.year = year;
        this.price = price;
        
    }

    public String toString() {
        String str;
        str = "Book - " + bookTitle + "("+ year + ")\n";
        str = str + "Publisher - " + publisher + "\n";
        str = str + "Price - " + price;
        return str;
    } 

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
    
    public static String GETCOLOR() {
         return color;
    }
    
        
}   
